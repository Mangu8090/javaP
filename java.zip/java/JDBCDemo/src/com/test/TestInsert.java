package com.test;


	import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

	public class TestInsert {
		public static void main(String[] args) {
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				System.out.println("Driver Reg Success");
				String url = "jdbc:oracle:thin:@Localhost:1521:xe";
				String user = "system";
				String pass = "orcl11g";
			
					Connection con = DriverManager.getConnection(url, user, pass);
					System.out.println("Conn success");
					con.setAutoCommit(false);
					//Statement stmt = con.createStatement();
					String cmd="insert into emp_tbi(empid,ename,empsalary) values(es.nextval,?,?)";
					PreparedStatement pstmt=con.prepareStatement(cmd);
					//pstmt.setInt(1, 1004);
					pstmt.setString(1, "j");
					pstmt.setInt(2, 10005);
					int n=pstmt.executeUpdate();
					//int n=stmt.executeUpdate(cmd);
					System.out.println("insert success n="+n);
					System.out.println("1.Commit 2.Rollback");
					Scanner sc= new Scanner(System.in);
					int option=sc.nextInt();
					if(option==1)
						{con.commit();}
					else
						{con.rollback();}
					con.close();
			}
					catch (ClassNotFoundException e) {
						e.printStackTrace();
			} catch (SQLException e) {
				//System.out.println(e);
				
			}
		
			// 
		}
	}
	