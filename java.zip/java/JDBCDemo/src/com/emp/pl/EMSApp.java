package com.emp.pl;

import java.util.Scanner;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.service.EmployeeService;
import com.emp.service.EmployeeServiceImp1;

public class EMSApp {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee name");
		String name=sc.next();
		System.out.println("Enter sal");
		int sal=sc.nextInt();
		
		EmployeeBean bean=new EmployeeBean();
		bean.setEname(name);
		bean.setEsal(sal);
		EmployeeService service=new EmployeeServiceImp1();
		try{
			
		int id=service.addEmployee(bean);
		System.out.println("Employee added success id"+id);
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
	}
}
