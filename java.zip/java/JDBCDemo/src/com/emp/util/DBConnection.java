package com.emp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	
	public DBConnection() {
		
	}

	public static Connection getConnection()
	{
		Connection con=null;
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "system";
		String pass = "orcl11g";
	
			try {
				con = DriverManager.getConnection(url, user, pass);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return(con);
	}
}
