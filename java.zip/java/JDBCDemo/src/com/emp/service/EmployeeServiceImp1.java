package com.emp.service;

import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDao;
import com.emp.dao.EmployeeDaoImp1;
import com.emp.exception.EmployeeException;

public class EmployeeServiceImp1 implements EmployeeService{
	private EmployeeDao employeeDao=new EmployeeDaoImp1();
	
	public int addEmployee(EmployeeBean bean)throws EmployeeException{
	int id=employeeDao.addEmployee(bean);
	return id;
	}

}
