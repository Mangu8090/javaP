import java.util.Scanner;

class Calculator
{
	int num1;
	int num2;
	public Calculator(){};
	public Calculator(int num1, int num2) {
		this.num1 = num1;
		this.num2 = num2;
	}
	public float divide()
	{
		
		float result=0.0f;
		try{
			result=num1/num2;
		}
		catch(ArithmeticException ae)
		{
			System.out.println(""+"Please see");
		}
		catch(ArrayIndexOutOfBoundsException aex){
			System.out.println(""+"Please check the array size");
		}
		catch(Exception e)
		{
			System.out.println(""+"Other Exception");
		}
		finally {
			System.out.println("this block is alwaya executed");
		}
		return result;
	}
}
	
public class ExceptionDemo
{
    public static void main(String args[])
    {
    	Scanner sc= new Scanner(System.in);
    	System.out.println("enter num1");
         int num1=sc.nextInt();
         int num2=sc.nextInt();
         Calculator c=new Calculator(num1,num2);
         System.out.println("div of 2 nums"+c.divide());
         
    }
}
