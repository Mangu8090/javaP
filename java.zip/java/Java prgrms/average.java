class Avg{

public static void main(String args[])
	{
		{
			int avg=0;
		   
		   
		   for(int j=0;j<5;j++)
			{
				avg=avg + Integer.parseInt(args[j]);
			}
			avg= avg/5;	
			System.out.println( "the avg is :" +avg);
		}
}

}
	