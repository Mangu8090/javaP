class GreetMe
{
	public static void main(String args[])
		{
			System.out.println(" Welcome To Capgemini");
		}
}

public class Welcome{
public static void main(String args[])
		{
			String name=args[0];
			String city=args[1];
			int mySal=Integer.parseInt(args[2]);
			int age=Integer.parseInt(args[3]);
			System.out.println("hbd:" +name);
			System.out.println("Ur salary is:" +mySal);
			System.out.println(" HBD sam" +name);
		}
}


	
