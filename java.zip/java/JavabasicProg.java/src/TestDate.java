import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;


public class TestDate {

	public static void main(String[] args) {
		LocalDate today=LocalDate.now();
		System.out.println("today is"+today);
		
		//LocalDateTime to=LocalDateTime.now();
		System.out.println("today is in dd-mmm-yyyy"+today.format(DateTimeFormatter.ofPattern("dd-mmm-yyyy")));
		System.out.println("My doj");
		LocalDate myDoj=LocalDate.of(2013,11,21);
		System.out.println("today is"+myDoj);
		System.out.println(" date after 2 days"+today.plusDays(2));
		Period per=Period.between(myDoj, today);
		System.out.println("My exp is:"+per.getYears()+"Years"+ per.getMonths()+
				"Months" +per.getDays()+"days");
		
		//String myDOBs="12-Jan-1990";
		//DateTimeFormatter myFormatter=DateTimeFormatter.ofPattern("dd-mmm-yyyy");
		
		//LocalDate myDOB=LocalDate.parse(myDOBs,myFormatter );
		//System.out.println(" My Date of Birth:" +myDOB.format(myFormatter));
	
	}

}
