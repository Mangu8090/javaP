
public class Tablet extends Medicines{
	String type;
public Tablet()
{
	super();
}
public Tablet(String Name, String cmpName, String expDate, float price,
		String type)
{
	super(Name,cmpName,expDate,price);
	this.type=type;
	
}
@Override
public String toString()
{
	return (super.toString()+"\n type:"+type);
}
}
