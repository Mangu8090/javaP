
public class TestStudent {

	public static void main(String[] args) {
		student s1=new student();
		s1.setRollNo(30);
		s1.setStuname("jain");
		s1.setMarks(67);

		student s2=new student();
		s1.setRollNo(32);
		s1.setStuname("jenny");
		s1.setMarks(76);
		System.out.println("Roll No: "+s1.getRollno()+"\nStudent Name: "+s1.getStuName()
				+"Marks: "+s1.getMarks());
		
		System.out.println("Roll No: "+s2.getRollno()+"\nStudent Name: "+s2.getStuName()
				+"Marks: "+s2.getMarks());
	}

}
