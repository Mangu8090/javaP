
public class WageEmp extends Emp{
int noOfHrs;
int ratePerHrs;
public WageEmp()
{ super();
}
public WageEmp(int empId,String empName,float empSal,int noOfHrs,int ratePerHrs)
{
	super(empId, empName, empSal);
	this.noOfHrs= noOfHrs;
	this.ratePerHrs=ratePerHrs;
	
}
public String dispEmpInfo()
{
	return super.dispEmpInfo() +
	"WageEmp[noOHrs=" +noOfHrs+ ",ratePerHour="+ratePerHrs;
}
public float calcAnnual()
{
	return (super.calcAnnual())+(noOfHrs* ratePerHrs*22*12);
}
}
