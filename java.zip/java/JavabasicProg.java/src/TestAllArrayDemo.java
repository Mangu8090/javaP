
public class TestAllArrayDemo {

	public static void main(String[] args){
		Emp emps[]=new Emp[6];
		emps[0]=new Emp(111,"varsha",1000.0F);
		emps[1]=new WageEmp(222,"sam",2000.0F,3,300);
		emps[2]=new SalesMgr(333,"abhi",3000.0F,3,300,6,500000);
		emps[3]= new Emp(444,"Tejas",78000.0F);
		emps[4]=new WageEmp(555,"Tripti",45000.0F,4,400);
		emps[5]=new SalesMgr(666,"jay",1000.0F,6,500,4566,8);
		
		for(int i=0;i<emps.length;i++)
		{
			
				System.out.println( i+ "th SalesMgr Info:" +emps[i].dispEmpInfo());
				System.out.println(  "Annual Salary:" +emps[i].calcAnnual());
				if(emps[i] instanceof SalesMgr)
				{
					System.out.println( i+ "is employee" +"\n");
				}
				else if(emps[i] instanceof WageEmp)
				{
					System.out.println( i+ "is wage employee" +"\n");
			    }
				else
				{
					System.out.println( i+ "is sales employee" +"\n");
				}
		}
}}

