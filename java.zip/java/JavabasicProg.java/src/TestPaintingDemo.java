
public class TestPaintingDemo {
	public static void main(String[] args)
	{
		Shape s1=new Circle(6);
		Shape s2=new Sphere(6);
		
		s1.drawShape();
		s2.drawShape();
		System.out.println("Area of shape1:" +s1.calcArea());
		System.out.println("Area of shape1:" +s2.calcArea());
		
		System.out.println("Circum of s1:" +s1.calcCircum());
		System.out.println("Volume of s2:" +s2.calcCircum());
	}
}
