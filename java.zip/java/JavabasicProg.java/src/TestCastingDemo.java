
public class TestCastingDemo {
public static void main(String[] args)
{
	Emp e1=null;
	e1= new Emp(111,"Siya",2000.0F);
	WageEmp e2= new WageEmp(222,"sam",2000.0F,5,400);
	SalesMgr e3= new SalesMgr(452,"priya",5000,5,40000,2,4);
	Emp e4= new WageEmp(444,"abhi",4000.0F,2,200);
	Emp e5=new SalesMgr(666,"nitin",4000.0F,2,1400,6,4000000);
	WageEmp e6= new SalesMgr(555,"Tejas",5000.0F,1,300,5,5000000);
	e2=(WageEmp)e4;
	System.out.println(e2.calcAnnual());
	e2=(WageEmp)e1;
	System.out.println(e2.calcAnnual());
	if( e1 instanceof Emp)
	{
		System.out.println("Yes e1 is Emp");
	}
	else
	{
		System.out.println("No");
	}
	if(e1 instanceof SalesMgr)
	{
		System.out.println("Yes e1 is SalesMgr");
	}
	else
	{
		System.out.println("Not SalesMgr");
	}
	}
}
