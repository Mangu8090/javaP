import java.io.IOException;


public class ThrowDemo {
	public void method1()throws IOException
	{
		System.out.println(" I am in method1 of ThrowDemo");
		method2();
	}
	public void method2() throws IOException
	{
		System.out.println(" I am in method2 of ThrowDemo");
}
}
