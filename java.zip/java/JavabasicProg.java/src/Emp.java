
public class Emp {

	static{
		System.out.println("static block is invoked at time"+ " when the classes are loaded in the"
	+" Memory by class loader");
		
	}
	  private int empId;
	  private String empName;
	  private float empSalary;
	  private static int count;
	  public Emp()
	  { }
	  
	  public Emp(int empId,String empName,float empSalary){
	 	   
	 	   this.empId=empId;
	 	   this.empName=empName;
	 	   this.empSalary=empSalary;
	 	   count++;
	    }
	   public static void getCount(){
		   System.out.println(" Emp count is:" +count);
	   }
	  public String dispEmpInfo()
	  {
		  
		  return "Emp[empId=" +empId+ ",empName="+empName+ ", Basic Emp Sal=" +empSalary+"]";
	  }
	  public float calcAnnual()
	  {
		  return empSalary*12;
	  }
}
