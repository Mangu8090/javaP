
public class student {

	private int rollno;
	private String stuName;
	private int marks;
	
	public student()
	{}
	
	public int getRollno()
	{
		return rollno;
	}
	
	public void setRollNo(int rollNo)
	{
		this.rollno=rollNo;
	}
	public String getStuName()
	{
		return stuName;
	}
	public void setStuname(String stuName){
		this.stuName=stuName;
	}
	public int getMarks()
	{
		return marks;
	}
	public void setMarks(int marks)
	{
		this.marks=marks;
	}
}
