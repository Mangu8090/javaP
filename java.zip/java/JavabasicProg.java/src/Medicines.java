
public abstract class Medicines {

	private String Name;
	private String cmpName;
	private String expDate;
	private float price;
	
	public Medicines() {
		super();
	}
	
	public Medicines(String Name, String cmpName, String expDate, float price)
	{
		
		this.Name = Name;
		this.cmpName = cmpName;
		this.expDate = expDate;
		this.price = price;
	}
	
	public String toString(){
		return "medicine name:" +Name+ ",company name:" +cmpName+ ",expiry date:" +expDate+",price:"+price;
}}
