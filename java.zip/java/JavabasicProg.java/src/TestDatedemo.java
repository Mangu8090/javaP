
public class TestDatedemo {

	public static void main(String[] args) 
	{
		Date jain= null;
		jain=new Date();
		
	Date jain1= new Date(03,04,2011);
		System.out.println("my doj is" +jain1.dispDate());
		
		Date doj= new Date();
		System.out.println("doj is" +doj.dispDate());
	}

}
