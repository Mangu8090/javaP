
public class TestInterfaceDemo {
              public static void main(String[] args){
            	  Printable p1=new Customer(222,"varsha");
            	 p1.print();
            	//  pArr[1]=new Customer(111,"varshu");
            	  //pArr[0].print();
            	 //pArr[1].print();
            	 System.out.println(((Customer)p1).sayHi());
              }
}
